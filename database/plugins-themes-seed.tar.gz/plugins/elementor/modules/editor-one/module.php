<?php

namespace Elementor\Modules\EditorOne;

use Elementor\Core\Admin\EditorOneMenu\Elementor_One_Menu_Manager;
use Elementor\Core\Base\Module as BaseModule;
use Elementor\Modules\EditorOne\Classes\Menu_Config;
use Elementor\Modules\EditorOne\Classes\Menu_Data_Provider;
use Elementor\Modules\EditorOne\Components\Sidebar_Navigation_Handler;
use Elementor\Modules\EditorOne\Components\Top_Bar_Handler;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
class Module extends BaseModule {

	const CUSTOM_REACT_APP_PAGES = [
		'elementor-element-manager',
	];

	public function get_name(): string {
		return 'editor-one';
	}

	public function __construct() {
		parent::__construct();

		if ( is_admin() ) {
			$this->add_component( 'editor-one-menu-manager', new Elementor_One_Menu_Manager() );
			$this->add_component( 'sidebar-navigation-handler', new Sidebar_Navigation_Handler() );
			$this->add_component( 'top-bar-handler', new Top_Bar_Handler() );
		}

		add_action( 'current_screen', function () {
			$menu_data_provider = Menu_Data_Provider::instance();

			if ( ! $menu_data_provider->is_editor_one_admin_page() ) {
				return;
			}

			add_action( 'admin_enqueue_scripts', function () {
				$this->enqueue_styles();
			} );
		} );

		add_filter( 'elementor/admin-top-bar/is-active', function ( $_is_active ) {
			return false;
		} );
	}

	/**
	 * Check if current page has a custom React app that uses @elementor/ui
	 *
	 * @return bool
	 */
	private function is_custom_react_app_page() {
		$current_screen = get_current_screen();

		if ( ! $current_screen ) {
			return false;
		}

		foreach ( self::CUSTOM_REACT_APP_PAGES as $page_slug ) {
			if ( str_contains( $current_screen->id ?? '', $page_slug ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Enqueue admin styles
	 */
	private function enqueue_styles() {

		wp_enqueue_style( 'elementor-admin' );

		wp_enqueue_style(
			'elementor-editor-one-common',
			$this->get_css_assets_url( 'editor-one-common' ),
			[ 'elementor-admin' ],
			ELEMENTOR_VERSION
		);

		if ( ! $this->is_custom_react_app_page() ) {
			wp_enqueue_style(
				'elementor-editor-one-elements',
				$this->get_css_assets_url( 'editor-one-elements' ),
				[ 'elementor-editor-one-common' ],
				ELEMENTOR_VERSION
			);

			wp_enqueue_style(
				'elementor-editor-one-tables',
				$this->get_css_assets_url( 'editor-one-tables' ),
				[ 'elementor-editor-one-common' ],
				ELEMENTOR_VERSION
			);
		}

		wp_enqueue_script(
			'editor-one-admin',
			$this->get_js_assets_url( 'editor-one-admin' ),
			[ 'jquery' ],
			ELEMENTOR_VERSION,
			true
		);
	}
}
