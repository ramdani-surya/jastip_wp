<?php
namespace Elementor\Modules\AtomicWidgets\Elements\Atomic_Heading;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Inline_Editing_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Link_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Widget_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Template;
use Elementor\Modules\AtomicWidgets\PropTypes\Attributes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Html_V3_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Link_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Style_Definition;
use Elementor\Modules\AtomicWidgets\Styles\Style_Variant;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Atomic_Heading extends Atomic_Widget_Base {
	use Has_Template;

	const LINK_BASE_STYLE_KEY = 'link-base';

	public static $widget_description = 'Display a heading with customizable tag, styles, and link options.';

	public static function get_element_type(): string {
		return 'e-heading';
	}

	public function get_title() {
		return esc_html__( 'Heading', 'elementor' );
	}

	public function get_keywords() {
		return [ 'ato', 'atom', 'atoms', 'atomic' ];
	}

	public function get_icon() {
		return 'eicon-e-heading';
	}

	protected static function define_props_schema(): array {
		return [
			'classes' => Classes_Prop_Type::make()
				->default( [] ),

			'tag' => String_Prop_Type::make()
				->enum( [ 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ] )
				->default( 'h2' )
				->description( 'The HTML tag for the heading element. Could be h1, h2, up to h6' ),

			'title' => Html_V3_Prop_Type::make()
				->default( [
					'content'  => String_Prop_Type::generate( __( 'This is a title', 'elementor' ) ),
					'children' => [],
				] )
				->description( 'The text content of the heading.' )
				->alias( 'text', 'content', 'heading' ),

			'link' => Link_Prop_Type::make(),

			'attributes' => Attributes_Prop_Type::make()->meta( Overridable_Prop_Type::ignore() ),
		];
	}

	protected function define_atomic_controls(): array {
		$content_section = Section::make()
			->set_label( __( 'Content', 'elementor' ) )
			->set_id( 'content' )
			->set_items( [
				Inline_Editing_Control::bind_to( 'title' )
					->set_placeholder( __( 'Type your title here', 'elementor' ) )
					->set_label( __( 'Title', 'elementor' ) ),
			] );

		return [
			$content_section,
			Section::make()
				->set_label( __( 'Settings', 'elementor' ) )
				->set_id( 'settings' )
				->set_items( $this->get_settings_controls() ),
		];
	}

	protected function get_settings_controls(): array {
		return [
			Select_Control::bind_to( 'tag' )
				->set_options([
					[
						'value' => 'h1',
						'label' => 'H1',
					],
					[
						'value' => 'h2',
						'label' => 'H2',
					],
					[
						'value' => 'h3',
						'label' => 'H3',
					],
					[
						'value' => 'h4',
						'label' => 'H4',
					],
					[
						'value' => 'h5',
						'label' => 'H5',
					],
					[
						'value' => 'h6',
						'label' => 'H6',
					],
				])
				->set_label( __( 'Tag', 'elementor' ) ),
			Link_Control::bind_to( 'link' )
				->set_placeholder( __( 'Type or paste your URL', 'elementor' ) )
				->set_label( __( 'Link', 'elementor' ) )
				->set_meta( [
					'topDivider' => true,
				] ),
			Text_Control::bind_to( '_cssid' )
			->set_label( __( 'ID', 'elementor' ) )
			->set_meta( $this->get_css_id_control_meta() ),
		];
	}

	protected function define_base_styles(): array {
		$margin_value = Size_Prop_Type::generate( [
			'unit' => 'px',
			'size' => 0 ,
		] );

		return [
			'base' => Style_Definition::make()
				->add_variant(
					Style_Variant::make()
						->add_prop( 'margin', $margin_value )
				),
			self::LINK_BASE_STYLE_KEY => Style_Definition::make()
				->add_variant(
					Style_Variant::make()
						->add_prop( 'all', 'unset' )
						->add_prop( 'cursor', 'pointer' )
				),
		];
	}

	protected function get_templates(): array {
		return [
			'elementor/elements/atomic-heading' => __DIR__ . '/atomic-heading.html.twig',
		];
	}

	public function render_markdown(): string {
		$settings = $this->get_atomic_settings();
		$title = wp_strip_all_tags( $settings['title'] ?? '' );

		if ( empty( $title ) ) {
			return '';
		}

		$tag = $settings['tag'] ?? 'h2';
		$level_map = [
			'h1' => 1,
			'h2' => 2,
			'h3' => 3,
			'h4' => 4,
			'h5' => 5,
			'h6' => 6,
		];
		$level = $level_map[ $tag ] ?? 2;

		$md = str_repeat( '#', $level ) . ' ' . $title;

		if ( ! empty( $settings['link']['href'] ) ) {
			$md = str_repeat( '#', $level ) . ' [' . $title . '](' . esc_url( $settings['link']['href'] ) . ')';
		}

		return $md;
	}
}
