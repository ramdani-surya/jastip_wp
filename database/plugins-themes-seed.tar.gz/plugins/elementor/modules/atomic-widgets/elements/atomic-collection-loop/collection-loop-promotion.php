<?php

namespace Elementor\Modules\AtomicWidgets\Elements\Atomic_Collection_Loop;

use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Element_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Element_Template;
use Elementor\Modules\AtomicWidgets\Elements\Promotions\Preserves_Children_Subtree;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Style_Definition;
use Elementor\Modules\AtomicWidgets\Styles\Style_Variant;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Collection_Loop_Promotion extends Atomic_Element_Base {
	use Has_Element_Template;
	use Preserves_Children_Subtree;

	const BASE_STYLE_KEY = 'base';

	public function __construct( $data = [], $args = null ) {
		parent::__construct( $data, $args );
		$this->meta( 'is_container', true );
		$this->meta( 'is_pro_promotion', true );
	}

	public static function get_type() {
		return 'e-collection-loop';
	}

	public static function get_element_type(): string {
		return self::get_type();
	}

	public function get_title() {
		return esc_html__( 'Loop', 'elementor' );
	}

	public function get_icon() {
		return 'eicon-loop-widget';
	}

	protected static function define_props_schema(): array {
		return [
			'classes' => Classes_Prop_Type::make()
				->default( [] ),
		];
	}

	protected function define_atomic_controls(): array {
		return [];
	}

	protected function define_base_styles(): array {
		return [
			static::BASE_STYLE_KEY => Style_Definition::make()
				->add_variant(
					Style_Variant::make()
						->add_prop( 'display', String_Prop_Type::generate( 'block' ) )
				),
		];
	}

	protected function should_show_in_panel() {
		return false;
	}

	protected function should_print_empty() {
		return false;
	}

	public function print_content() {
	}

	protected function get_templates(): array {
		return [
			'elementor/elements/collection-loop-promotion' => __DIR__ . '/collection-loop-promotion.html.twig',
		];
	}
}
