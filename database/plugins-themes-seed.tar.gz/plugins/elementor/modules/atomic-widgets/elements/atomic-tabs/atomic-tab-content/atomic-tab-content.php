<?php
namespace Elementor\Modules\AtomicWidgets\Elements\Atomic_Tabs\Atomic_Tab_Content;

use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Element_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Element_Template;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Style_Definition;
use Elementor\Modules\AtomicWidgets\Styles\Style_Variant;
use Elementor\Modules\AtomicWidgets\Styles\Style_States;
use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Attributes_Prop_Type;
use Elementor\Modules\AtomicWidgets\Elements\Base\Render_Context;
use Elementor\Modules\AtomicWidgets\Elements\Atomic_Tabs\Atomic_Tabs\Atomic_Tabs;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Atomic_Tab_Content extends Atomic_Element_Base {
	use Has_Element_Template;

	const BASE_STYLE_KEY = 'base';

	public static $widget_description = 'A tab content panel. Accepts any widget type inside. The index of this e-tab-content MUST match the index of the corresponding e-tab in the e-tabs-menu.';

	public function __construct( $data = [], $args = null ) {
		parent::__construct( $data, $args );
		$this->meta( 'permanently_locked', true );
	}

	public static function get_type() {
		return 'e-tab-content';
	}

	public static function get_element_type(): string {
		return 'e-tab-content';
	}

	public function get_title() {
		return esc_html__( 'Tab content', 'elementor' );
	}

	public function get_keywords() {
		return [ 'ato', 'atom', 'atoms', 'atomic', 'tab', 'content', 'tabs' ];
	}

	public function get_icon() {
		return 'eicon-layout';
	}

	public function should_show_in_panel() {
		return false;
	}

	protected static function define_props_schema(): array {
		return [
			'classes' => Classes_Prop_Type::make()
				->default( [] ),
			'tab-id' => String_Prop_Type::make(),
			'attributes' => Attributes_Prop_Type::make()->meta( Overridable_Prop_Type::ignore() ),
		];
	}

	protected function define_atomic_controls(): array {
		return [
			Section::make()
				->set_label( __( 'Settings', 'elementor' ) )
				->set_id( 'settings' )
				->set_items( [] ),
		];
	}

	protected function define_atomic_style_states(): array {
		$selected_state = Style_States::get_class_states_map()['selected'];

		return [ $selected_state ];
	}

	protected function define_base_styles(): array {
		$styles = [
			'display' => String_Prop_Type::generate( 'block' ),
			'padding' => Size_Prop_Type::generate( [
				'size' => 10,
				'unit' => 'px',
			] ),
			'min-width' => Size_Prop_Type::generate( [
				'size' => 30,
				'unit' => 'px',
			] ),
		];

		return [
			static::BASE_STYLE_KEY => Style_Definition::make()
				->add_variant(
					Style_Variant::make()
						->add_props( $styles )
				),
		];
	}

	protected function define_initial_attributes() {
		return [
			'role' => 'tabpanel',
		];
	}

	protected function get_templates(): array {
		return [
			'elementor/elements/atomic-tab-content' => __DIR__ . '/atomic-tab-content.html.twig',
		];
	}

	protected function build_template_context(): array {
		$tabs_context = Render_Context::get( Atomic_Tabs::class );
		$default_active_tab = $tabs_context['default-active-tab'];
		$get_tab_content_index = $tabs_context['get-tab-content-index'];
		$tabs_id = $tabs_context['tabs-id'];

		$index = $get_tab_content_index( $this->get_id() );
		$is_active = $default_active_tab === $index;

		return array_merge( $this->build_base_template_context(), [
			'is_active' => $is_active,
			'tab_id' => Atomic_Tabs::get_tab_id( $tabs_id, $index ),
			'tab_content_id' => Atomic_Tabs::get_tab_content_id( $tabs_id, $index ),
		] );
	}
}
